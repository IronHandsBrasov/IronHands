
// Оновлений код React з формою відгуків, стилем і шрифтами
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone, Mail, Facebook, Instagram } from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function MrIronHandsLanding() {
  const [language, setLanguage] = useState("ro");
  const [form, setForm] = useState({
    name: "",
    address: "",
    datetime: "",
    services: {
      furniture: false,
      tv: false,
      plumbing: false,
      painting: false,
      other: "",
    },
    materials: "",
    phone: "",
  });

  const [reviews, setReviews] = useState([
    { stars: 5, text: "Foarte punctual și atent la detalii. Recomand!" },
    { stars: 5, text: "Fast and professional service. Thank you!" },
    { stars: 5, text: "Все якісно і швидко. Дуже задоволений!" }
  ]);

  const [newReview, setNewReview] = useState({ stars: 5, text: "" });
  const [reviewSent, setReviewSent] = useState(false);

  const handleReviewSubmit = () => {
    if (newReview.text.trim().length >= 5) {
      setReviews([newReview, ...reviews]);
      setNewReview({ stars: 5, text: "" });
      setReviewSent(true);
    }
  };

  useEffect(() => {
    if (reviewSent) {
      const timeout = setTimeout(() => setReviewSent(false), 3000);
      return () => clearTimeout(timeout);
    }
  }, [reviewSent]);

  const translations = {
    reviewsTitle: {
      ro: "Recenzii",
      en: "Reviews",
      uk: "Відгуки"
    },
    reviewPlaceholder: {
      ro: "Scrie un comentariu...",
      en: "Write a comment...",
      uk: "Напишіть коментар..."
    },
    reviewLabel: {
      ro: "Lasă o recenzie",
      en: "Leave a review",
      uk: "Залишити відгук"
    },
    submit: {
      ro: "Trimite",
      en: "Submit",
      uk: "Надіслати"
    },
    starsLabel: {
      ro: "Stele:",
      en: "Stars:",
      uk: "Оцінка:"
    },
    thankYou: {
      ro: "Mulțumim pentru recenzie!",
      en: "Thank you for your review!",
      uk: "Дякуємо за відгук!"
    }
  };

  const t = translations;

  return (
    <div className="p-6 space-y-12 bg-gradient-to-br from-orange-100 to-green-100 min-h-screen font-sans">
      <section className="bg-white p-6 rounded-xl shadow">
        <h2 className="text-2xl font-semibold mb-4">{t.reviewsTitle[language]}</h2>

        <div className="mb-6">
          <h3 className="text-lg font-medium mb-2">{t.reviewLabel[language]}</h3>
          <div className="flex items-center gap-2 mb-2">
            <label>{t.starsLabel[language]}</label>
            <select
              className="border p-1 rounded"
              value={newReview.stars}
              onChange={(e) => setNewReview({ ...newReview, stars: parseInt(e.target.value) })}
            >
              {[1, 2, 3, 4, 5].map((n) => (
                <option key={n} value={n}>{n}</option>
              ))}
            </select>
          </div>
          <textarea
            className="w-full border rounded p-2 mb-2"
            rows={3}
            placeholder={t.reviewPlaceholder[language]}
            value={newReview.text}
            onChange={(e) => setNewReview({ ...newReview, text: e.target.value })}
          />
          <Button onClick={handleReviewSubmit}>{t.submit[language]}</Button>

          {reviewSent && (
            <p className="text-green-600 mt-2 animate-pulse">{t.thankYou[language]}</p>
          )}
        </div>

        <ul className="space-y-4">
          <AnimatePresence>
            {reviews.map((r, i) => (
              <motion.li
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className="border-b pb-2"
              >
                <div className="text-yellow-500">{"⭐".repeat(r.stars)}</div>
                <div>{r.text}</div>
              </motion.li>
            ))}
          </AnimatePresence>
        </ul>
      </section>
    </div>
  );
}
