export function Card({ children }: any) {
  return <div className='rounded-xl shadow bg-white'>{children}</div>;
}
export function CardContent({ children }: any) {
  return <div className='p-4'>{children}</div>;
}
