// pages/index.tsx
import MrIronHandsLanding from "../components/MrIronHandsLanding";

export default function Home() {
  return <MrIronHandsLanding />;
}
